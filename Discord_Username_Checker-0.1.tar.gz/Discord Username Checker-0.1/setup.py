import setuptools

setuptools.setup(
    name= 'Discord Username Checker',
    version= '0.1',
    author= 'Hassan',
    description= 'Discord Username Checker By Hassan',
    packages=setuptools.find_packages(),
    classifiers=[
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent",
    "License :: OSI Approved :: MIT License"
    ]
)